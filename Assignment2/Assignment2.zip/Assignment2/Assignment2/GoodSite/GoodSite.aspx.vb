﻿
Partial Class GoodSite_GoodSite
    Inherits System.Web.UI.Page

End Class
