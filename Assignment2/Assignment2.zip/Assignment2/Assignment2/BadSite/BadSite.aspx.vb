﻿
Partial Class BadSite_BadSite
    Inherits System.Web.UI.Page

End Class
